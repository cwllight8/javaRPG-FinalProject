package edu.neumont.light.javarpg.models.enums;

public enum MonsterType {
	
	SillySlime, BadBird, StabbingSkull

}
