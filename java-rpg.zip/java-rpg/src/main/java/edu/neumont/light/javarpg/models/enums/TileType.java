package edu.neumont.light.javarpg.models.enums;

public enum TileType {
	Water, Rock, Grass, Tree, Building1, Building2, Building3, Building4, Player

}
