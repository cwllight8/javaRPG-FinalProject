package edu.neumont.light.javarpg.models.enums;

public enum SkillEffect {

	DamageMultiplyer, DamageResistance
}
